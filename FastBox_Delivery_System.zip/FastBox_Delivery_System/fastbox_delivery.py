import json
import math
import os
import sys


def read_text_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


class JSONParseError(ValueError):
    pass


class JSONParser:
    def __init__(self, text):
        self.text = text
        self.i = 0
        self.n = len(text)

    def parse(self):
        value = self.parse_value()
        self.skip_whitespace()
        if self.i != self.n:
            raise JSONParseError(f"Unexpected trailing data at position {self.i}")
        return value

    def parse_value(self):
        self.skip_whitespace()
        if self.i >= self.n:
            raise JSONParseError("Unexpected end of input")
        ch = self.text[self.i]
        if ch == '{':
            return self.parse_object()
        if ch == '[':
            return self.parse_array()
        if ch == '"':
            return self.parse_string()
        if ch == 'n' and self.text.startswith('null', self.i):
            self.i += 4
            return None
        if ch == 't' and self.text.startswith('true', self.i):
            self.i += 4
            return True
        if ch == 'f' and self.text.startswith('false', self.i):
            self.i += 5
            return False
        if ch == '-' or ch.isdigit():
            return self.parse_number()
        raise JSONParseError(f"Unexpected character '{ch}' at position {self.i}")

    def parse_object(self):
        self.i += 1
        obj = {}
        self.skip_whitespace()
        if self.peek() == '}':
            self.i += 1
            return obj
        while True:
            self.skip_whitespace()
            key = self.parse_string()
            self.skip_whitespace()
            self.expect(':')
            self.skip_whitespace()
            value = self.parse_value()
            obj[key] = value
            self.skip_whitespace()
            if self.peek() == '}':
                self.i += 1
                break
            self.expect(',')
        return obj

    def parse_array(self):
        self.i += 1
        arr = []
        self.skip_whitespace()
        if self.peek() == ']':
            self.i += 1
            return arr
        while True:
            self.skip_whitespace()
            arr.append(self.parse_value())
            self.skip_whitespace()
            if self.peek() == ']':
                self.i += 1
                break
            self.expect(',')
        return arr

    def parse_string(self):
        self.expect('"')
        start = self.i
        result = []
        while self.i < self.n:
            ch = self.text[self.i]
            if ch == '"':
                self.i += 1
                return ''.join(result)
            if ch == '\\':
                self.i += 1
                if self.i >= self.n:
                    raise JSONParseError("Unterminated escape sequence")
                esc = self.text[self.i]
                if esc == '"':
                    result.append('"')
                elif esc == '\\':
                    result.append('\\')
                elif esc == '/':
                    result.append('/')
                elif esc == 'b':
                    result.append('\b')
                elif esc == 'f':
                    result.append('\f')
                elif esc == 'n':
                    result.append('\n')
                elif esc == 'r':
                    result.append('\r')
                elif esc == 't':
                    result.append('\t')
                elif esc == 'u':
                    self.i += 1
                    hex_digits = self.text[self.i:self.i + 4]
                    if len(hex_digits) != 4 or any(c not in '0123456789abcdefABCDEF' for c in hex_digits):
                        raise JSONParseError("Invalid unicode escape sequence")
                    result.append(chr(int(hex_digits, 16)))
                    self.i += 3
                else:
                    raise JSONParseError(f"Invalid escape character '\\{esc}'")
            else:
                result.append(ch)
            self.i += 1
        raise JSONParseError("Unterminated string")

    def parse_number(self):
        start = self.i
        if self.peek() == '-':
            self.i += 1
        self.consume_digits()
        if self.peek() == '.':
            self.i += 1
            self.consume_digits()
        if self.peek() in 'eE':
            self.i += 1
            if self.peek() in '+-':
                self.i += 1
            self.consume_digits()
        num_text = self.text[start:self.i]
        try:
            return int(num_text) if '.' not in num_text and 'e' not in num_text and 'E' not in num_text else float(num_text)
        except ValueError as exc:
            raise JSONParseError(f"Invalid number {num_text}") from exc

    def consume_digits(self):
        if not self.peek().isdigit():
            raise JSONParseError(f"Expected digit at position {self.i}")
        while self.peek().isdigit():
            self.i += 1

    def skip_whitespace(self):
        while self.i < self.n and self.text[self.i] in ' \n\r\t':
            self.i += 1

    def peek(self):
        return self.text[self.i] if self.i < self.n else ''

    def expect(self, char):
        if self.peek() != char:
            raise JSONParseError(f"Expected '{char}' at position {self.i}, found '{self.peek()}'")
        self.i += 1


def parse_json(text):
    return JSONParser(text).parse()


def normalize_data(data):
    normalized = {}

    if isinstance(data.get("warehouses"), list):
        normalized["warehouses"] = {
            item["id"]: item["location"] for item in data["warehouses"]
        }
    else:
        normalized["warehouses"] = data["warehouses"]

    if isinstance(data.get("agents"), list):
        normalized["agents"] = {
            item["id"]: item["location"] for item in data["agents"]
        }
    else:
        normalized["agents"] = data["agents"]

    packages = []
    for package in data["packages"]:
        packages.append({
            "id": package.get("id"),
            "warehouse": package.get("warehouse") or package.get("warehouse_id"),
            "destination": package["destination"],
        })
    normalized["packages"] = packages

    return normalized


def euclidean_distance(point_a, point_b):
    return math.hypot(point_a[0] - point_b[0], point_a[1] - point_b[1])


def assign_packages_to_agents(data):
    warehouses = data["warehouses"]
    agents = data["agents"]
    assignments = {agent_id: [] for agent_id in agents}
    for package in data["packages"]:
        warehouse_id = package["warehouse"]
        warehouse_location = warehouses[warehouse_id]
        nearest_agent = None
        nearest_distance = float("inf")
        for agent_id, agent_location in agents.items():
            distance = euclidean_distance(agent_location, warehouse_location)
            if distance < nearest_distance:
                nearest_distance = distance
                nearest_agent = agent_id
        assignments[nearest_agent].append(package)
    return assignments


def simulate_deliveries(data, assignments):
    agents = data["agents"]
    warehouses = data["warehouses"]
    report = {}

    for agent_id, package_list in assignments.items():
        current_location = agents[agent_id]
        total_distance = 0.0
        delivered_count = 0

        for package in package_list:
            warehouse_location = warehouses[package["warehouse"]]
            destination = package["destination"]

            total_distance += euclidean_distance(current_location, warehouse_location)
            total_distance += euclidean_distance(warehouse_location, destination)
            current_location = destination
            delivered_count += 1

        efficiency = total_distance / delivered_count if delivered_count else 0.0
        report[agent_id] = {
            "packages_delivered": delivered_count,
            "total_distance": round(total_distance, 2),
            "efficiency": round(efficiency, 2),
        }

    best_agent = max(report.items(), key=lambda item: item[1]["packages_delivered"] / item[1]["efficiency"] if item[1]["efficiency"] > 0 else 0)
    report["best_agent"] = best_agent[0]
    return report


def save_report(path, report):
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps(report, indent=2))


def main():
    input_path = "data.json"
    output_path = "report.json"

    if len(sys.argv) > 1:
        input_path = sys.argv[1]
        if len(sys.argv) == 2:
            base_name = os.path.basename(input_path)
            if base_name.lower().endswith(".json") and base_name != "data.json":
                output_path = base_name
    if len(sys.argv) > 2:
        output_path = sys.argv[2]

    if not os.path.exists(input_path):
        print(f"Input file not found: {input_path}")
        sys.exit(1)

    source_text = read_text_file(input_path)
    data = parse_json(source_text)
    data = normalize_data(data)
    assignments = assign_packages_to_agents(data)
    report = simulate_deliveries(data, assignments)
    save_report(output_path, report)
    print(f"Report written to {output_path}")


if __name__ == "__main__":
    main()
