# FastBox Delivery System

A simple Python utility for assigning delivery packages to the nearest available agent and generating a summary report.

## What this does

- Reads a JSON input file describing warehouses, agents, and packages.
- Normalizes the data into a consistent format.
- Assigns each package to the nearest agent based on Euclidean distance.
- Simulates the delivery path for each agent.
- Writes a JSON report with delivery counts, distances, efficiency, and the best-performing agent.

## How to use

From the repository root, run the script with a case file path:

```bash
python fastbox_delivery.py Case/test_case_1.json
```

With the current behavior, if you provide only one argument, the output will save using the same base filename as the input case file. For example:

- Input: `Case/test_case_1.json`
- Output: `test_case_1.json`

If you want to explicitly set a different output path, provide it as a second argument:

```bash
python fastbox_delivery.py Case/test_case_1.json output_report.json
```

## File structure

- `fastbox_delivery.py` — main script
- `data.json` — default input file
- `report.json` — default output file
- `Case/` — folder containing sample case files
- `base_case.json` — example base case file
- `test_case_1.json` through `test_case_10.json` — sample input cases

## Notes

- The script expects valid JSON input.
- If the input file does not exist, it prints an error and exits.
- The report is written with pretty-printed JSON.

## Example output

The generated report includes:

- `packages_delivered`
- `total_distance`
- `efficiency`
- `best_agent`

Thats it — a quick, readable tool for testing delivery assignment logic.
